<?php
/**
 * GET /analytics/*
 *
 * One controller for the five analytics endpoints the dashboard uses. Each
 * route delegates to a provider so the transport code stays tiny.
 *
 * @package G2ABA
 */

namespace WordPressistic\G2ABA\REST;

use WordPressistic\G2ABA\Cache;
use WordPressistic\G2ABA\Providers\Insightistic_Provider;
use WordPressistic\G2ABA\Providers\Revenue_Provider;
use WordPressistic\G2ABA\Providers\Segments_Provider;
use WordPressistic\G2ABA\Providers\SEO_Provider;
use WordPressistic\G2ABA\Providers\Store_Provider;
use WordPressistic\G2ABA\Range;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Analytics_Controller extends REST_Controller {
	public function register_routes(): void {
		$common_args = array(
			'from' => array( 'type' => 'string' ),
			'to'   => array( 'type' => 'string' ),
		);

		// NOTE: /analytics/bookings and /analytics/memberships moved to
		// Analytics_Detail_Controller in 0.4.0 (canonical envelope + detail
		// payloads). /analytics/overview stays here untouched.
		foreach (
			array(
				'overview'         => 'overview',
				'store'            => 'store',
				'seo'              => 'seo',
				'insightistic'     => 'insightistic',
				'shooter-insights' => 'shooter_insights',
			) as $slug => $method
		) {
			register_rest_route(
				$this->namespace,
				'/analytics/' . $slug,
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, $method ),
					'permission_callback' => array( $this, 'read_permissions_check' ),
					'args'                => $common_args,
				)
			);
		}
	}

	public function overview( \WP_REST_Request $req ) {
		$range = Range::from_request( $req );
		$data  = Cache::remember(
			'overview_' . $range->from . '_' . $range->to,
			60,
			static function () use ( $range ) {
				return ( new Revenue_Provider() )->overview( $range );
			}
		);
		return $this->ok( $data );
	}

	public function store( \WP_REST_Request $req ) {
		$range = Range::from_request( $req );
		$data  = Cache::remember(
			'store_' . $range->from . '_' . $range->to,
			60,
			static function () use ( $range ) {
				return ( new Store_Provider() )->analytics( $range );
			}
		);
		return $this->ok( $data );
	}

	public function seo( \WP_REST_Request $req ) {
		$range = Range::from_request( $req );
		$data  = Cache::remember(
			'seo_' . $range->from . '_' . $range->to,
			300,
			static function () use ( $range ) {
				return ( new SEO_Provider() )->analytics( $range );
			}
		);
		return $this->ok( $data );
	}

	public function shooter_insights() { // phpcs:ignore Squiz.Commenting.FunctionComment.Missing
		$data = Cache::remember(
			'shooter_insights',
			120,
			static function () {
				return ( new Segments_Provider() )->shooter_insights();
			}
		);
		return $this->ok( $data );
	}

	public function insightistic( \WP_REST_Request $req ) {
		$range = Range::from_request( $req );
		$data  = Cache::remember(
			'insightistic_' . $range->from . '_' . $range->to,
			300,
			static function () use ( $range ) {
				return ( new Insightistic_Provider() )->analytics( $range );
			}
		);
		return $this->ok( $data );
	}
}
