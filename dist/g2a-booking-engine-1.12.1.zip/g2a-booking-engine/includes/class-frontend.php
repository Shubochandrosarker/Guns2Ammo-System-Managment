<?php
/**
 * Frontend orchestrator.
 *
 * Renders the new "Calendly-style" two-column booking experience:
 *   LEFT  — service info card (title, badges, description, feature bullets).
 *   RIGHT — date calendar + time slots → details form → confirmation.
 *
 * The visual design is driven entirely by saved options (the Form Customizer
 * tab in Settings) so the same plugin can be styled per site without code.
 *
 * Phase 1 shortcodes:
 *   [g2a_lane_booking]      — full booking flow.
 *   [g2a_booking_form]      — alias that routes a saved form/type into the flow.
 *
 * @package G2AB
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class G2AB_Frontend {

	private static $instance = null;
	private $enqueued = false;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'g2a_lane_booking', array( $this, 'render_lane_booking' ) );
		add_shortcode( 'g2a_booking_form', array( $this, 'render_booking_form' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ), 5 );
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue_return_assets' ), 20 );
		// Mark booking pages uncacheable EARLY (before render) so the wp_rest nonce
		// embedded in the form can't be served stale from a full-page/edge cache and
		// 403 the booking POST. The mid-render call in render_lane_booking() is too
		// late for page caches that snapshot at the end of the request.
		add_action( 'template_redirect', array( $this, 'maybe_mark_booking_page_uncacheable' ) );
	}

	public function register_assets() {
		wp_register_style(
			'g2ab-frontend',
			G2AB_URL . 'assets/css/frontend.css',
			array(),
			G2AB_VERSION
		);
		wp_register_script(
			'g2ab-frontend',
			G2AB_URL . 'assets/js/frontend.js',
			array(),
			G2AB_VERSION,
			true
		);
	}

	public function maybe_enqueue_return_assets() {
		if ( isset( $_GET['g2ab_paid'] ) || isset( $_GET['g2ab_cancel'] ) || isset( $_GET['g2ab_pay'] ) ) {
			$this->enqueue_assets();
		}
	}

	private function enqueue_assets() {
		if ( $this->enqueued ) {
			return;
		}
		wp_enqueue_style( 'g2ab-frontend' );
		wp_enqueue_script( 'g2ab-frontend' );

		// Entitlement snapshot for the CURRENT authenticated user only — never
		// resolved from a typed email, never another user's data. Used by the
		// widgets to render "included with your plan" copy; the server remains
		// the authority on pricing at booking time.
		$entitlement = array( 'eligible' => false, 'plan_name' => '' );
		if ( is_user_logged_in() && class_exists( 'G2AB_Checkout_Policy' ) ) {
			$ent = G2AB_Checkout_Policy::lane_entitlement( get_current_user_id() );
			$entitlement['eligible']  = ! empty( $ent['eligible'] );
			$entitlement['plan_name'] = (string) ( $ent['plan_name'] ?? '' );
		}

		wp_localize_script(
			'g2ab-frontend',
			'G2AB_DATA',
			array(
				'rest_url'        => esc_url_raw( rest_url( G2AB_REST_NAMESPACE . '/' ) ),
				'rest_namespace'  => G2AB_REST_NAMESPACE,
				'nonce'           => wp_create_nonce( 'wp_rest' ),
				'currency'        => get_option( 'g2ab_currency', 'USD' ),
				'currency_prefix' => $this->currency_prefix(),
				'is_logged_in'    => is_user_logged_in(),
				'entitlement'     => $entitlement,
				'i18n'            => array(
					'confirming'          => __( "We're confirming your payment…", 'g2a-booking' ),
					'confirming_body'     => __( 'Hold tight — this usually only takes a few seconds.', 'g2a-booking' ),
					'confirmed_title'     => __( 'Booking confirmed.', 'g2a-booking' ),
					'confirmed_body'      => __( 'Your payment was received. A confirmation email is on its way.', 'g2a-booking' ),
					'confirmation'        => __( 'Confirmation:', 'g2a-booking' ),
					'not_verified_title'  => __( "We couldn't confirm your payment yet.", 'g2a-booking' ),
					'not_verified_body'   => __( "Your reservation is not confirmed until payment is verified. If you completed checkout you'll get an email as soon as it settles — otherwise you can try again below.", 'g2a-booking' ),
					'try_again'           => __( 'Try payment again', 'g2a-booking' ),
					'cancelled_title'     => __( 'Payment was cancelled — your lane is not reserved.', 'g2a-booking' ),
					'cancelled_body'      => __( 'No charge was made. Any held time or seats will be released shortly unless you complete payment.', 'g2a-booking' ),
					'resuming'            => __( 'Preparing secure checkout…', 'g2a-booking' ),
					'resume_failed'       => __( 'We could not restart checkout.', 'g2a-booking' ),
					'try_later'           => __( 'Please try again in a moment.', 'g2a-booking' ),
					'slot_released_title' => __( 'That time is no longer available.', 'g2a-booking' ),
					'slot_released_body'  => __( 'Your hold was released and the slot has since been taken or expired. Please pick a new time and book again.', 'g2a-booking' ),
					'pick_new_time'       => __( 'Pick a new time', 'g2a-booking' ),
					'already_paid'        => __( "This booking is already paid — you're all set.", 'g2a-booking' ),
					'dismiss'             => __( 'Dismiss', 'g2a-booking' ),
				),
			)
		);
		$this->enqueued = true;
	}

	/**
	 * Format an amount in the SITE currency (never a hardcoded '$').
	 */
	private function format_price( $amount ) {
		if ( function_exists( 'g2ab_format_currency' ) ) {
			return g2ab_format_currency( (float) $amount );
		}
		return '$' . number_format( (float) $amount, 2 );
	}

	/**
	 * The currency prefix ("$", "€", "USD ") for client-side price rendering,
	 * derived from the same map g2ab_format_currency() uses so PHP and JS
	 * always agree.
	 */
	private function currency_prefix() {
		if ( function_exists( 'g2ab_format_currency' ) ) {
			$prefix = str_replace( number_format_i18n( 0, 2 ), '', g2ab_format_currency( 0 ) );
			if ( '' !== $prefix ) {
				return $prefix;
			}
		}
		return '$';
	}

	/**
	 * URL the visitor should come back to after logging in — the page that
	 * embeds the booking widget.
	 */
	private function current_page_url() {
		if ( is_singular() ) {
			$permalink = get_permalink();
			if ( $permalink ) {
				return $permalink;
			}
		}
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
		return home_url( $request_uri );
	}

	private function mark_booking_page_dynamic() {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) define( 'DONOTCACHEPAGE', true );
		if ( ! defined( 'DONOTCACHEOBJECT' ) ) define( 'DONOTCACHEOBJECT', true );
		if ( ! defined( 'DONOTCACHEDB' ) ) define( 'DONOTCACHEDB', true );
		nocache_headers();
	}

	/**
	 * If the current singular view contains a booking shortcode, force it to be
	 * uncacheable so its embedded wp_rest nonce stays fresh. Runs at
	 * template_redirect — early enough for page-cache plugins — and emits a
	 * no-store header for edge/CDN caches that ignore DONOTCACHEPAGE.
	 */
	public function maybe_mark_booking_page_uncacheable() {
		if ( is_admin() ) {
			return;
		}
		$post = get_post();
		if ( ! $post instanceof WP_Post ) {
			return;
		}
		$content = (string) $post->post_content;
		if ( ! has_shortcode( $content, 'g2a_lane_booking' ) && ! has_shortcode( $content, 'g2a_booking_form' ) ) {
			return;
		}
		$this->mark_booking_page_dynamic();
		if ( ! headers_sent() ) {
			header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
		}
	}

	/**
	 * Read all design-token options and return a sanitised tokens array.
	 *
	 * Each token has a sensible default that matches the reference design
	 * (dark gradient, blue accent, rounded corners, Inter typography).
	 */
	private function get_design_tokens() {
		$tokens = array(
			// Defaults track the theme's own live brass/ember/void design
			// tokens (via var(--color-*)) rather than a hardcoded hex, so the
			// widget's out-of-box colors follow the site's actual brand and
			// its light/dark toggle. Any value saved in the Form Customizer
			// still wins.
			'theme'           => sanitize_key( get_option( 'g2ab_form_theme', 'midnight' ) ),
			'layout'          => sanitize_key( get_option( 'g2ab_form_layout', 'split' ) ),
			'primary'         => $this->sanitize_color( get_option( 'g2ab_form_primary', 'var(--color-brass)' ) ),
			'accent'          => $this->sanitize_color( get_option( 'g2ab_form_accent', 'var(--color-ember)' ) ),
			'bg'              => $this->sanitize_color( get_option( 'g2ab_form_bg', 'var(--color-void)' ) ),
			'surface'         => $this->sanitize_color( get_option( 'g2ab_form_surface', 'var(--color-surface-1)' ) ),
			'surface2'        => $this->sanitize_color( get_option( 'g2ab_form_surface2', 'var(--color-surface-2)' ) ),
			'text'            => $this->sanitize_color( get_option( 'g2ab_form_text', 'var(--color-white)' ) ),
			'muted'           => $this->sanitize_color( get_option( 'g2ab_form_muted', 'var(--color-silver)' ) ),
			'border'          => $this->sanitize_color( get_option( 'g2ab_form_border', 'rgba(255,255,255,0.10)' ) ),
			'radius'          => $this->sanitize_radius( get_option( 'g2ab_form_radius', '16' ) ),
			'radius_pill'     => $this->sanitize_radius( get_option( 'g2ab_form_radius_pill', '999' ) ),
			'font'            => sanitize_key( get_option( 'g2ab_form_font', 'inter' ) ),
			'animations'      => (int) get_option( 'g2ab_form_animations', 1 ),
			'show_pricing'    => (int) get_option( 'g2ab_form_show_pricing', 1 ),
			'show_lane_grid'  => (int) get_option( 'g2ab_form_show_lane_grid', 1 ),
			'title_override'  => sanitize_text_field( get_option( 'g2ab_form_title', '' ) ),
			'subtitle'        => sanitize_text_field( get_option( 'g2ab_form_subtitle', '' ) ),
			'description'     => wp_kses_post( get_option( 'g2ab_form_description', '' ) ),
			'features'        => array_filter( array_map( 'trim', preg_split( '/\r?\n/', (string) get_option( 'g2ab_form_features', "Instant confirmation email\nReschedule or cancel anytime\nNo spam — just your booking" ) ) ) ),
			'badge_duration'  => (int) get_option( 'g2ab_form_badge_duration', 1 ),
			'badge_price'     => (int) get_option( 'g2ab_form_badge_price', 1 ),
			'continue_label'  => sanitize_text_field( get_option( 'g2ab_form_continue_label', __( 'Continue', 'g2a-booking' ) ) ),
			'submit_label'    => sanitize_text_field( get_option( 'g2ab_form_submit_label', '' ) ),
			'shadow'          => sanitize_text_field( get_option( 'g2ab_form_shadow', '0 30px 80px rgba(8,12,32,0.45)' ) ),
		);
		return apply_filters( 'g2ab_form_design_tokens', $tokens );
	}

	private function sanitize_color( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value ) return '';
		if ( preg_match( '/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $value ) ) {
			return $value;
		}
		if ( preg_match( '/^rgba?\(\s*\d+\s*,\s*\d+\s*,\s*\d+(\s*,\s*[\d.]+)?\s*\)$/', $value ) ) {
			return $value;
		}
		// A bare CSS var() reference to one of the theme's own design tokens
		// — used by get_design_tokens()'s own defaults below so the widget's
		// out-of-box colors track the site's live brass/ember/void palette
		// (and its light/dark toggle) instead of a hardcoded hex that
		// silently drifts out of sync with a theme re-skin, the way this
		// widget's colors previously did. Restricted to var(--name) /
		// var(--name, #hex) so this can never become a CSS-injection vector.
		if ( preg_match( '/^var\(--[a-zA-Z0-9-]+(?:,\s*(?:#[0-9a-fA-F]{3,8}|[a-zA-Z]+))?\)$/', $value ) ) {
			return $value;
		}
		return '';
	}

	private function sanitize_radius( $value ) {
		$value = preg_replace( '/[^0-9.]/', '', (string) $value );
		if ( '' === $value ) return '16';
		return (string) min( 999, max( 0, (float) $value ) );
	}

	private function font_family_for( $key ) {
		$stacks = array(
			'system'  => '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif',
			'inter'   => '"Inter","Segoe UI",Roboto,Helvetica,Arial,sans-serif',
			'manrope' => '"Manrope","Inter","Segoe UI",sans-serif',
			'rubik'   => '"Rubik","Inter","Segoe UI",sans-serif',
			'dmsans'  => '"DM Sans","Inter","Segoe UI",sans-serif',
		);
		return $stacks[ $key ] ?? $stacks['inter'];
	}

	private function font_link_for( $key ) {
		$urls = array(
			'inter'   => 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap',
			'manrope' => 'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap',
			'rubik'   => 'https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;600;700&display=swap',
			'dmsans'  => 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&display=swap',
		);
		return $urls[ $key ] ?? '';
	}

	private function resource_type_for_booking_type( $booking_type ) {
		$settings = isset( $booking_type->settings ) ? json_decode( (string) $booking_type->settings, true ) : array();
		$configured = is_array( $settings ) && ! empty( $settings['resource_type'] ) ? sanitize_key( $settings['resource_type'] ) : '';
		if ( in_array( $configured, array( 'lane', 'classroom', 'instructor', 'package' ), true ) ) {
			return $configured;
		}
		$category = isset( $booking_type->category ) ? sanitize_key( $booking_type->category ) : 'lane';
		return 'class' === $category ? 'classroom' : 'lane';
	}

	private function resource_label_for_type( $type ) {
		$labels = array(
			'classroom'  => __( 'Classroom', 'g2a-booking' ),
			'instructor' => __( 'Instructor', 'g2a-booking' ),
			'package'    => __( 'Package', 'g2a-booking' ),
			'lane'       => __( 'Lane', 'g2a-booking' ),
		);
		return $labels[ $type ] ?? __( 'Resource', 'g2a-booking' );
	}

	private function get_form_for_booking_type( $booking_type, $form_slug = '' ) {
		global $wpdb;
		$form_table = $wpdb->prefix . 'g2ab_forms';
		if ( $form_slug ) {
			$form = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$form_table} WHERE slug = %s AND is_active = 1", $form_slug ) );
			if ( $form ) return $form;
		}
		if ( ! empty( $booking_type->form_id ) ) {
			$form = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$form_table} WHERE id = %d AND is_active = 1", (int) $booking_type->form_id ) );
			if ( $form ) return $form;
		}
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$form_table} WHERE slug = %s AND is_active = 1", 'default-lane-booking' ) );
	}

	private function display_pricing_for_booking_type( $booking_type ) {
		$subtotal = round( (float) $booking_type->base_price, 2 );
		$pricing  = array(
			'subtotal'        => $subtotal,
			'discount_amount' => 0.0,
			'total'           => $subtotal,
			'discount_label'  => '',
		);
		$pricing = apply_filters( 'g2ab_booking_display_pricing', $pricing, $booking_type, 1, get_current_user_id() );
		$pricing['subtotal']        = max( 0, round( (float) ( $pricing['subtotal'] ?? $subtotal ), 2 ) );
		$pricing['discount_amount'] = max( 0, min( $pricing['subtotal'], round( (float) ( $pricing['discount_amount'] ?? 0 ), 2 ) ) );
		$pricing['total']           = max( 0, round( (float) ( $pricing['total'] ?? ( $pricing['subtotal'] - $pricing['discount_amount'] ) ), 2 ) );
		$pricing['discount_label']  = sanitize_text_field( $pricing['discount_label'] ?? '' );
		return $pricing;
	}

	/**
	 * Main shortcode renderer.
	 */
	public function render_lane_booking( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'booking_type' => 'lane-booking',
				'form'         => 'default-lane-booking',
				'theme'        => '',
			),
			$atts,
			'g2a_lane_booking'
		);

		$this->mark_booking_page_dynamic();
		$this->enqueue_assets();

		global $wpdb;

		$bt_table     = $wpdb->prefix . 'g2ab_booking_types';
		$booking_type = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$bt_table} WHERE slug = %s AND is_active = 1", $atts['booking_type'] ) );
		if ( ! $booking_type ) {
			return $this->render_error( __( 'Booking type not configured. Visit G2A Booking → Booking Types.', 'g2a-booking' ) );
		}

		$requested      = $booking_type;
		$viewer_member  = $this->current_user_is_member();
		$requested_only = ! empty( $requested->members_only );
		if ( $requested_only && ! $viewer_member ) {
			$public = $this->get_public_lane_booking_type();
			if ( $public ) {
				$booking_type = $public;
			}
		}

		$resource_type  = $this->resource_type_for_booking_type( $booking_type );
		$resource_label = $this->resource_label_for_type( $resource_type );

		$resources = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, name, slug, capacity FROM {$wpdb->prefix}g2ab_resources WHERE type = %s AND is_active = 1 ORDER BY sort_order ASC, name ASC",
			$resource_type
		) );
		if ( empty( $resources ) ) {
			return $this->render_error( sprintf(
				/* translators: %s resource label */
				__( 'No %s resources are configured. Visit G2A Booking → Resources.', 'g2a-booking' ),
				strtolower( $resource_label )
			) );
		}

		$form         = $this->get_form_for_booking_type( $booking_type, $atts['form'] );
		$display_pric = $this->display_pricing_for_booking_type( $booking_type );

		$fields = array();
		if ( $form ) {
			$fields = $wpdb->get_results( $wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}g2ab_form_fields WHERE form_id = %d ORDER BY sort_order ASC",
				(int) $form->id
			) );
		}

		$tokens      = $this->get_design_tokens();
		$override    = $atts['theme'] ? sanitize_key( $atts['theme'] ) : $tokens['theme'];
		$tokens['theme'] = $override;

		$instance_id = 'g2ab-' . substr( md5( uniqid( 'g2ab', true ) ), 0, 12 );
		$today       = current_time( 'Y-m-d' );
		$max_days    = (int) get_option( 'g2ab_max_booking_advance_days', 90 );

		// Optional Google font link (rendered once per page).
		$font_url = $this->font_link_for( $tokens['font'] );
		if ( $font_url ) {
			static $printed = array();
			if ( empty( $printed[ $tokens['font'] ] ) ) {
				printf( '<link rel="stylesheet" href="%s" />', esc_url( $font_url ) );
				$printed[ $tokens['font'] ] = true;
			}
		}

		$service_title    = $tokens['title_override'] ?: $booking_type->name;
		$service_subtitle = $tokens['subtitle'] ?: '';
		$service_desc     = $tokens['description'] ?: '';
		$price_total      = (float) $display_pric['total'];

		// Structured entitlement for the CURRENT authenticated user only (the
		// server re-checks at booking time; this is display state, not policy).
		$member_included = false;
		$member_plan     = '';
		if ( is_user_logged_in() && class_exists( 'G2AB_Checkout_Policy' ) ) {
			$entitlement     = G2AB_Checkout_Policy::lane_entitlement( get_current_user_id() );
			$member_included = ! empty( $entitlement['eligible'] );
			$member_plan     = (string) ( $entitlement['plan_name'] ?? '' );
		}

		if ( $member_included ) {
			$price_label = __( 'Included', 'g2a-booking' );
		} else {
			$price_label = $price_total <= 0 ? __( 'FREE', 'g2a-booking' ) : $this->format_price( $price_total );
		}

		// Payment-aware CTA. An explicit Form Customizer submit label still wins.
		if ( '' !== $tokens['submit_label'] ) {
			$submit_label = $tokens['submit_label'];
		} elseif ( $member_included || $price_total <= 0 ) {
			$submit_label = __( 'Confirm reservation', 'g2a-booking' );
		} else {
			/* translators: %s formatted amount */
			$submit_label = sprintf( __( 'Pay %s securely', 'g2a-booking' ), $this->format_price( $price_total ) );
		}

		$login_url = wp_login_url( $this->current_page_url() );

		// Unified "what do you want to book?" switch — only shown when there are
		// published events with upcoming dates. The lane flow below is unchanged;
		// the event mode mounts the self-contained [g2a_event_booking] widget.
		$event_widget = ( class_exists( 'G2AB_Events' ) ) ? do_shortcode( '[g2a_event_booking]' ) : '';
		$has_events   = ( '' !== trim( (string) $event_widget ) && false === strpos( $event_widget, 'g2ab-evb--empty' ) );
		$switch_id    = $instance_id . '-switch';

		ob_start();

		if ( $has_events ) :
		?>
		<div class="g2ab-unified g2ab-theme-<?php echo esc_attr( $tokens['theme'] ); ?>" id="<?php echo esc_attr( $switch_id ); ?>" style="<?php echo esc_attr( $this->build_css_vars( $tokens ) ); ?>">
			<div class="g2ab-unified__switch">
				<span class="g2ab-unified__q" id="<?php echo esc_attr( $switch_id ); ?>-q"><?php esc_html_e( 'What do you want to book?', 'g2a-booking' ); ?></span>
				<div class="g2ab-unified__opts" role="tablist" aria-labelledby="<?php echo esc_attr( $switch_id ); ?>-q">
					<button type="button" class="g2ab-unified__opt is-active" data-mode="lane"
						id="<?php echo esc_attr( $switch_id ); ?>-tab-lane" role="tab" aria-selected="true"
						aria-controls="<?php echo esc_attr( $switch_id ); ?>-panel-lane" tabindex="0"><?php esc_html_e( 'Lane / Range Time', 'g2a-booking' ); ?></button>
					<button type="button" class="g2ab-unified__opt" data-mode="event"
						id="<?php echo esc_attr( $switch_id ); ?>-tab-event" role="tab" aria-selected="false"
						aria-controls="<?php echo esc_attr( $switch_id ); ?>-panel-event" tabindex="-1"><?php esc_html_e( 'Events &amp; Classes', 'g2a-booking' ); ?></button>
				</div>
			</div>
			<div class="g2ab-unified__panel" data-mode-panel="lane" id="<?php echo esc_attr( $switch_id ); ?>-panel-lane" role="tabpanel" aria-labelledby="<?php echo esc_attr( $switch_id ); ?>-tab-lane">
		<?php endif; ?>
		<div id="<?php echo esc_attr( $instance_id ); ?>"
			class="g2ab g2ab-booking g2ab-theme-<?php echo esc_attr( $tokens['theme'] ); ?> g2ab-layout-<?php echo esc_attr( $tokens['layout'] ); ?> <?php echo $tokens['animations'] ? 'g2ab-animate' : 'g2ab-static'; ?>"
			data-booking-type-id="<?php echo (int) $booking_type->id; ?>"
			data-form-id="<?php echo $form ? (int) $form->id : 0; ?>"
			data-resource-label="<?php echo esc_attr( $resource_label ); ?>"
			data-resource-type="<?php echo esc_attr( $resource_type ); ?>"
			data-duration="<?php echo (int) $booking_type->duration_min; ?>"
			data-today="<?php echo esc_attr( $today ); ?>"
			data-max-days="<?php echo (int) $max_days; ?>"
			style="<?php echo esc_attr( $this->build_css_vars( $tokens ) ); ?>">

			<div class="g2ab-shell">

				<!-- LEFT: service info card -->
				<aside class="g2ab-aside">
					<div class="g2ab-card g2ab-aside__card">
						<div class="g2ab-aside__badges">
							<?php if ( $tokens['badge_duration'] ) : ?>
								<span class="g2ab-pill"><?php echo esc_html( (int) $booking_type->duration_min . ' ' . __( 'MIN', 'g2a-booking' ) ); ?></span>
							<?php endif; ?>
							<?php if ( $tokens['badge_price'] ) : ?>
								<span class="g2ab-pill g2ab-pill--accent"><?php echo esc_html( $price_label ); ?></span>
							<?php endif; ?>
						</div>

						<h2 class="g2ab-aside__title"><?php echo esc_html( $service_title ); ?></h2>

						<?php if ( $service_subtitle ) : ?>
							<p class="g2ab-aside__subtitle"><?php echo esc_html( $service_subtitle ); ?></p>
						<?php endif; ?>

						<?php if ( $service_desc ) : ?>
							<div class="g2ab-aside__desc"><?php echo wp_kses_post( wpautop( $service_desc ) ); ?></div>
						<?php endif; ?>

						<?php if ( ! empty( $tokens['features'] ) ) : ?>
							<ul class="g2ab-aside__features">
								<?php foreach ( $tokens['features'] as $feature ) : ?>
									<li>
										<span class="g2ab-dot" aria-hidden="true"></span>
										<span><?php echo esc_html( $feature ); ?></span>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>

						<?php if ( $tokens['show_pricing'] && $member_included ) : ?>
							<div class="g2ab-included">
								<span class="g2ab-included__mark" aria-hidden="true">✓</span>
								<div>
									<p class="g2ab-included__title">
										<?php
										echo esc_html( $member_plan
											? sprintf( /* translators: %s plan name */ __( 'Included with your %s membership', 'g2a-booking' ), $member_plan )
											: __( 'Included with your membership', 'g2a-booking' ) );
										?>
									</p>
									<p class="g2ab-included__due">
										<?php
										printf(
											/* translators: %s formatted zero amount, e.g. $0.00 */
											esc_html__( 'Amount due today: %s', 'g2a-booking' ),
											esc_html( $this->format_price( 0 ) )
										);
										?>
									</p>
								</div>
							</div>
						<?php elseif ( $tokens['show_pricing'] && (float) $display_pric['discount_amount'] > 0 ) : ?>
							<p class="g2ab-aside__discount-note">
								<?php
								printf(
									/* translators: 1: original formatted price, 2: discount label */
									esc_html__( 'Original %1$s. %2$s applied.', 'g2a-booking' ),
									esc_html( $this->format_price( (float) $display_pric['subtotal'] ) ),
									esc_html( $display_pric['discount_label'] ?: __( 'Member discount', 'g2a-booking' ) )
								);
								?>
							</p>
						<?php endif; ?>
					</div>
				</aside>

				<!-- RIGHT: booking stage -->
				<main class="g2ab-stage">

					<!-- ─────────────────────────────────────────────────
					     STAGE 1 — Pick a time
					     ───────────────────────────────────────────────── -->
					<section class="g2ab-stage__panel is-active" data-stage="time" aria-labelledby="<?php echo esc_attr( $instance_id ); ?>-stage-title">
						<header class="g2ab-stage__head">
							<h3 id="<?php echo esc_attr( $instance_id ); ?>-stage-title" class="g2ab-stage__title"><?php esc_html_e( 'Choose a date &amp; time', 'g2a-booking' ); ?></h3>
							<p class="g2ab-stage__meta">
								<?php
								/* translators: %s site timezone */
								printf( esc_html__( 'Times shown in %s', 'g2a-booking' ), esc_html( wp_timezone_string() ) );
								?>
							</p>
						</header>

						<?php if ( count( $resources ) > 1 && $tokens['show_lane_grid'] ) : ?>
							<div class="g2ab-resource-row">
								<label class="g2ab-field-label" for="<?php echo esc_attr( $instance_id ); ?>-resource">
									<?php /* translators: %s resource label */ printf( esc_html__( 'Select %s', 'g2a-booking' ), esc_html( $resource_label ) ); ?>
								</label>
								<div class="g2ab-resource-grid">
									<?php foreach ( $resources as $idx => $res ) : ?>
										<button type="button"
											class="g2ab-chip<?php echo 0 === $idx ? ' is-selected' : ''; ?>"
											data-resource-id="<?php echo (int) $res->id; ?>"
											data-resource-name="<?php echo esc_attr( $res->name ); ?>">
											<?php echo esc_html( $res->name ); ?>
										</button>
									<?php endforeach; ?>
								</div>
							</div>
						<?php else : ?>
							<input type="hidden" data-single-resource-id value="<?php echo (int) $resources[0]->id; ?>" />
							<input type="hidden" data-single-resource-name value="<?php echo esc_attr( $resources[0]->name ); ?>" />
						<?php endif; ?>

						<div class="g2ab-pick">
							<div class="g2ab-pick__cal">
								<div class="g2ab-cal" data-calendar>
									<header class="g2ab-cal__head">
										<button type="button" class="g2ab-cal__nav" data-cal-prev aria-label="<?php esc_attr_e( 'Previous month', 'g2a-booking' ); ?>">‹</button>
										<div class="g2ab-cal__title" data-cal-title></div>
										<button type="button" class="g2ab-cal__nav" data-cal-next aria-label="<?php esc_attr_e( 'Next month', 'g2a-booking' ); ?>">›</button>
									</header>
									<div class="g2ab-cal__dow">
										<?php
										$dow_labels = array( __( 'Mon', 'g2a-booking' ), __( 'Tue', 'g2a-booking' ), __( 'Wed', 'g2a-booking' ), __( 'Thu', 'g2a-booking' ), __( 'Fri', 'g2a-booking' ), __( 'Sat', 'g2a-booking' ), __( 'Sun', 'g2a-booking' ) );
										foreach ( $dow_labels as $label ) {
											echo '<span>' . esc_html( strtoupper( $label ) ) . '</span>';
										}
										?>
									</div>
									<div class="g2ab-cal__grid" data-cal-grid></div>
								</div>
							</div>
							<div class="g2ab-pick__slots">
								<p class="g2ab-pick__hint" data-slots-hint role="status" aria-live="polite"><?php esc_html_e( 'Pick a date to see available times', 'g2a-booking' ); ?></p>
								<div class="g2ab-slots" data-slots></div>
							</div>
						</div>

						<footer class="g2ab-stage__foot">
							<div class="g2ab-stage__summary" data-summary-pill hidden></div>
							<button type="button" class="g2ab-btn g2ab-btn--primary" data-go-form disabled>
								<?php echo esc_html( $tokens['continue_label'] ); ?>
							</button>
						</footer>
					</section>

					<!-- ─────────────────────────────────────────────────
					     STAGE 2 — Your details
					     ───────────────────────────────────────────────── -->
					<section class="g2ab-stage__panel" data-stage="form">
						<header class="g2ab-stage__head">
							<button type="button" class="g2ab-back" data-back-time>
								<span aria-hidden="true">‹</span> <?php esc_html_e( 'Back', 'g2a-booking' ); ?>
							</button>
							<h3 class="g2ab-stage__title"><?php esc_html_e( 'Your details', 'g2a-booking' ); ?></h3>
							<p class="g2ab-stage__meta" data-summary-line></p>
						</header>

						<?php if ( ! is_user_logged_in() ) : ?>
							<p class="g2ab-login-note">
								<?php esc_html_e( 'Already a member?', 'g2a-booking' ); ?>
								<a href="<?php echo esc_url( $login_url ); ?>"><?php esc_html_e( 'Log in to use your benefit', 'g2a-booking' ); ?></a>
								<span class="g2ab-login-note__hint"><?php esc_html_e( 'Continuing as a guest books at the full public price.', 'g2a-booking' ); ?></span>
							</p>
						<?php endif; ?>

						<form class="g2ab-form" novalidate
							action="javascript:void(0);"
							method="post"
							onsubmit="return false;"
							data-g2ab-form="1">
							<?php $this->render_form_fields( $fields ); ?>

							<?php if ( $tokens['show_pricing'] ) : ?>
								<div class="g2ab-order" data-order-summary>
									<p class="g2ab-order__title"><?php esc_html_e( 'Order summary', 'g2a-booking' ); ?></p>
									<?php if ( $member_included ) : ?>
										<div class="g2ab-order__row">
											<span>
												<?php
												echo esc_html( $member_plan
													? sprintf( /* translators: %s plan name */ __( 'Included with your %s membership', 'g2a-booking' ), $member_plan )
													: __( 'Included with your membership', 'g2a-booking' ) );
												?>
											</span>
											<span class="g2ab-order__amount" data-order-total><?php echo esc_html( $this->format_price( 0 ) ); ?></span>
										</div>
										<div class="g2ab-order__row g2ab-order__row--total">
											<span><?php esc_html_e( 'Amount due today', 'g2a-booking' ); ?></span>
											<span class="g2ab-order__amount" data-order-total><?php echo esc_html( $this->format_price( 0 ) ); ?></span>
										</div>
									<?php else : ?>
										<div class="g2ab-order__row">
											<span><span data-order-unit><?php echo esc_html( $this->format_price( (float) $display_pric['subtotal'] ) ); ?></span> × <span data-order-qty>1</span></span>
											<span data-order-subtotal><?php echo esc_html( $this->format_price( (float) $display_pric['subtotal'] ) ); ?></span>
										</div>
										<div class="g2ab-order__row g2ab-order__row--discount" data-order-discount-row<?php echo (float) $display_pric['discount_amount'] > 0 ? '' : ' hidden'; ?>>
											<span><?php echo esc_html( $display_pric['discount_label'] ?: __( 'Discount', 'g2a-booking' ) ); ?></span>
											<span data-order-discount>−<?php echo esc_html( $this->format_price( (float) $display_pric['discount_amount'] ) ); ?></span>
										</div>
										<div class="g2ab-order__row g2ab-order__row--total">
											<span><?php esc_html_e( 'Total due today', 'g2a-booking' ); ?></span>
											<span class="g2ab-order__amount" data-order-total><?php echo esc_html( $this->format_price( (float) $display_pric['total'] ) ); ?></span>
										</div>
										<?php if ( (float) $display_pric['total'] > 0 ) : ?>
											<p class="g2ab-order__note"><?php esc_html_e( 'Secure online payment. Your lane is held while you complete checkout — it is not reserved until payment succeeds.', 'g2a-booking' ); ?></p>
										<?php endif; ?>
									<?php endif; ?>
								</div>
							<?php endif; ?>

							<div class="g2ab-form__error" data-form-error role="alert" hidden></div>
							<div class="g2ab-form__status" data-form-status role="status" aria-live="polite" hidden></div>

							<footer class="g2ab-stage__foot">
								<button type="button" class="g2ab-btn g2ab-btn--ghost" data-back-time>
									<?php esc_html_e( 'Back', 'g2a-booking' ); ?>
								</button>
								<button type="submit" class="g2ab-btn g2ab-btn--primary" data-submit-cta>
									<?php echo esc_html( $submit_label ); ?>
								</button>
							</footer>
						</form>
					</section>

					<!-- ─────────────────────────────────────────────────
					     STAGE 3 — Done
					     ───────────────────────────────────────────────── -->
					<section class="g2ab-stage__panel" data-stage="done">
						<div class="g2ab-done">
							<div class="g2ab-done__confetti" data-done-confetti aria-hidden="true"></div>
							<div class="g2ab-done__check" aria-hidden="true">
								<svg viewBox="0 0 64 64" width="64" height="64"><circle cx="32" cy="32" r="30" fill="none" stroke="currentColor" stroke-width="3"/><path d="M20 33 L29 42 L45 24" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>
							</div>
							<h3 class="g2ab-done__title" data-done-title><?php esc_html_e( 'Booking confirmed', 'g2a-booking' ); ?></h3>
							<p class="g2ab-done__msg" data-done-msg></p>
							<div class="g2ab-done__recap" data-done-recap hidden>
								<div class="g2ab-done__recap-row">
									<span class="g2ab-done__recap-label"><?php esc_html_e( 'Resource', 'g2a-booking' ); ?></span>
									<span data-done-recap-resource></span>
								</div>
								<div class="g2ab-done__recap-row">
									<span class="g2ab-done__recap-label"><?php esc_html_e( 'When', 'g2a-booking' ); ?></span>
									<span data-done-recap-when></span>
								</div>
								<div class="g2ab-done__recap-row" data-done-recap-party-row hidden>
									<span class="g2ab-done__recap-label"><?php esc_html_e( 'Party size', 'g2a-booking' ); ?></span>
									<span data-done-recap-party></span>
								</div>
							</div>
							<p class="g2ab-done__id"><?php esc_html_e( 'Confirmation:', 'g2a-booking' ); ?> <code data-done-uuid></code></p>
							<button type="button" class="g2ab-btn g2ab-btn--primary g2ab-done__again" data-book-another>
								<?php echo esc_html( sprintf( /* translators: %s resource label, e.g. "Lane" */ __( 'Book Another %s', 'g2a-booking' ), $resource_label ) ); ?>
							</button>
						</div>
					</section>

				</main>
			</div>
		</div>
		<?php
		$this->render_inline_bootstrap( $instance_id, array(
			'member_included'     => $member_included,
			'plan_name'           => $member_plan,
			'pricing'             => $display_pric,
			'custom_submit_label' => (string) $tokens['submit_label'],
		) );
		?>
		<?php if ( $has_events ) : ?>
			</div><!-- /lane panel -->
			<div class="g2ab-unified__panel" data-mode-panel="event" id="<?php echo esc_attr( $switch_id ); ?>-panel-event" role="tabpanel" aria-labelledby="<?php echo esc_attr( $switch_id ); ?>-tab-event" hidden>
				<?php echo $event_widget; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
		</div><!-- /g2ab-unified -->
		<style>
		.g2ab-unified{max-width:980px;margin:24px auto;font-family:var(--g2ab-font,var(--font-body));}
		.g2ab-unified__switch{display:flex;flex-wrap:wrap;align-items:center;gap:12px 16px;background:var(--g2ab-surface,var(--color-gunmetal));border:1px solid var(--g2ab-border,var(--color-hairline));border-top:4px solid var(--g2ab-primary,var(--color-brass));border-radius:12px 12px 0 0;padding:16px 20px;}
		.g2ab-unified__q{font-size:13px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--g2ab-text,var(--color-white));}
		.g2ab-unified__opts{display:inline-flex;gap:8px;background:var(--g2ab-bg,var(--color-void));padding:4px;border-radius:999px;border:1px solid var(--g2ab-border,var(--color-hairline));}
		.g2ab-unified__opt{appearance:none;border:none;background:transparent;color:var(--g2ab-muted,var(--color-silver));padding:8px 18px;border-radius:999px;font-size:13px;font-weight:700;cursor:pointer;transition:all .15s ease;}
		.g2ab-unified__opt.is-active{background:var(--g2ab-primary,var(--color-brass));color:var(--color-ink);}
		.g2ab-unified__opt:focus-visible{outline:2px solid var(--g2ab-primary,var(--color-brass));outline-offset:2px;}
		@media (prefers-reduced-motion: reduce){.g2ab-unified__opt{transition:none;}}
		.g2ab-unified__panel{margin-top:-1px;}
		.g2ab-unified__panel[hidden]{display:none;}
		.g2ab-unified .g2ab-evb{margin-top:0;border-radius:0 0 12px 12px;border-top:none;max-width:none;}
		</style>
		<script>
		(function(){
			var root = document.getElementById(<?php echo wp_json_encode( $switch_id ); ?>);
			if (!root || root.dataset.switchBooted) return;
			root.dataset.switchBooted = '1';
			var opts = Array.prototype.slice.call(root.querySelectorAll('.g2ab-unified__opt'));
			var panels = root.querySelectorAll('[data-mode-panel]');
			function activate(btn, focus){
				var mode = btn.getAttribute('data-mode');
				opts.forEach(function(b){
					var on = b === btn;
					b.classList.toggle('is-active', on);
					b.setAttribute('aria-selected', on ? 'true' : 'false');
					b.tabIndex = on ? 0 : -1;
				});
				panels.forEach(function(p){ p.hidden = (p.getAttribute('data-mode-panel') !== mode); });
				if (focus) btn.focus();
			}
			opts.forEach(function(btn, i){
				btn.addEventListener('click', function(){ activate(btn, false); });
				btn.addEventListener('keydown', function(e){
					var dir = 0;
					if (e.key === 'ArrowRight' || e.key === 'ArrowDown') dir = 1;
					else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') dir = -1;
					else if (e.key === 'Home') { e.preventDefault(); activate(opts[0], true); return; }
					else if (e.key === 'End') { e.preventDefault(); activate(opts[opts.length - 1], true); return; }
					if (!dir) return;
					e.preventDefault();
					activate(opts[(i + dir + opts.length) % opts.length], true);
				});
			});
		})();
		</script>
		<?php endif; ?>
		<?php
		return ob_get_clean();
	}

	/**
	 * Build a `style=""` attribute value with CSS custom properties.
	 */
	private function build_css_vars( $tokens ) {
		$vars = array(
			'--g2ab-primary'  => $tokens['primary'],
			'--g2ab-accent'   => $tokens['accent'],
			'--g2ab-bg'       => $tokens['bg'],
			'--g2ab-surface'  => $tokens['surface'],
			'--g2ab-surface2' => $tokens['surface2'],
			'--g2ab-text'     => $tokens['text'],
			'--g2ab-muted'    => $tokens['muted'],
			'--g2ab-border'   => $tokens['border'],
			'--g2ab-radius'   => $tokens['radius'] . 'px',
			'--g2ab-radius-pill' => $tokens['radius_pill'] . 'px',
			'--g2ab-shadow'   => $tokens['shadow'],
			'--g2ab-font'     => $this->font_family_for( $tokens['font'] ),
		);
		$out = '';
		foreach ( $vars as $k => $v ) {
			if ( '' !== $v ) {
				$out .= $k . ':' . str_replace( array( ';', '"' ), '', (string) $v ) . ';';
			}
		}
		return $out;
	}

	/**
	 * Form fields renderer — unchanged structure, restyled by the new CSS.
	 */
	private function render_form_fields( $fields ) {
		if ( empty( $fields ) ) {
			echo '<p class="g2ab-muted">' . esc_html__( 'No form fields configured.', 'g2a-booking' ) . '</p>';
			return;
		}

		foreach ( $fields as $field ) {
			$key      = sanitize_key( $field->field_key );
			$type     = sanitize_key( $field->field_type );
			$label    = esc_html( $field->label );
			$required = (int) $field->is_required ? 'required' : '';
			$req_mark = (int) $field->is_required ? ' <span class="g2ab-req">*</span>' : '';
			$id       = 'g2ab-f-' . $key;
			$name     = 'fields[' . $key . ']';
			$ph       = $field->placeholder ? esc_attr( $field->placeholder ) : '';
			$help     = $field->help_text ? '<small class="g2ab-help">' . esc_html( $field->help_text ) . '</small>' : '';
			$opts     = json_decode( (string) $field->options, true );
			$opts     = is_array( $opts ) ? $opts : array();

			echo '<div class="g2ab-field g2ab-field--' . esc_attr( $type ) . '">';

			switch ( $type ) {
				case 'text':
				case 'email':
				case 'phone':
				case 'number':
					$input_type = 'phone' === $type ? 'tel' : $type;
					echo '<label class="g2ab-field-label" for="' . esc_attr( $id ) . '">' . $label . $req_mark . '</label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '<input type="' . esc_attr( $input_type ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" class="g2ab-input" placeholder="' . $ph . '" ' . esc_attr( $required ) . ' />';
					echo $help; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					break;
				case 'date':
				case 'time':
					echo '<label class="g2ab-field-label" for="' . esc_attr( $id ) . '">' . $label . $req_mark . '</label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '<input type="' . esc_attr( $type ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" class="g2ab-input" ' . esc_attr( $required ) . ' />';
					break;
				case 'dropdown':
					echo '<label class="g2ab-field-label" for="' . esc_attr( $id ) . '">' . $label . $req_mark . '</label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" class="g2ab-input" ' . esc_attr( $required ) . '>';
					echo '<option value="">' . esc_html__( '— Select —', 'g2a-booking' ) . '</option>';
					foreach ( $opts as $opt ) {
						$v = $opt['value'] ?? '';
						$l = $opt['label'] ?? '';
						echo '<option value="' . esc_attr( $v ) . '">' . esc_html( $l ) . '</option>';
					}
					echo '</select>';
					break;
				case 'radio':
					echo '<fieldset><legend class="g2ab-field-label">' . $label . $req_mark . '</legend>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					foreach ( $opts as $opt ) {
						$v = $opt['value'] ?? '';
						$l = $opt['label'] ?? '';
						echo '<label class="g2ab-radio"><input type="radio" name="' . esc_attr( $name ) . '" value="' . esc_attr( $v ) . '" ' . esc_attr( $required ) . ' /> ' . esc_html( $l ) . '</label>';
					}
					echo '</fieldset>';
					break;
				case 'checkbox':
				case 'waiver':
				case 'terms':
					echo '<label class="g2ab-checkbox"><input type="checkbox" name="' . esc_attr( $name ) . '" value="1" ' . esc_attr( $required ) . ' /> <span>' . $label . $req_mark . '</span></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					break;
				case 'hidden':
					echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $field->placeholder ?? '' ) . '" />';
					break;
				default:
					echo '<label class="g2ab-field-label" for="' . esc_attr( $id ) . '">' . $label . $req_mark . '</label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '<input type="text" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" class="g2ab-input" />';
			}
			echo '</div>';
		}
	}

	/**
	 * Alias shortcode that routes a saved form/booking-type into the flow.
	 */
	public function render_booking_form( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'id'           => 0,
				'type'         => '',
				'booking_type' => '',
				'form'         => '',
				'theme'        => '',
			),
			$atts,
			'g2a_booking_form'
		);

		global $wpdb;
		$form_slug    = sanitize_title( $atts['form'] );
		$booking_slug = sanitize_title( $atts['booking_type'] ?: $atts['type'] );

		if ( ! $form_slug && (int) $atts['id'] > 0 ) {
			$form = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}g2ab_forms WHERE id = %d AND is_active = 1",
				(int) $atts['id']
			) );
			if ( $form ) $form_slug = $form->slug;
		}

		if ( ! $booking_slug && (int) $atts['id'] > 0 ) {
			$bt = $wpdb->get_row( $wpdb->prepare(
				"SELECT slug FROM {$wpdb->prefix}g2ab_booking_types WHERE form_id = %d AND is_active = 1 ORDER BY id ASC LIMIT 1",
				(int) $atts['id']
			) );
			if ( $bt ) $booking_slug = $bt->slug;
		}

		return $this->render_lane_booking( array(
			'booking_type' => $booking_slug ?: 'lane-booking',
			'form'         => $form_slug ?: 'default-lane-booking',
			'theme'        => sanitize_key( $atts['theme'] ),
		) );
	}

	private function render_error( $msg ) {
		return '<div class="g2ab g2ab-error"><p>' . esc_html( $msg ) . '</p></div>';
	}

	/**
	 * Members-only display gate.
	 *
	 * Memberistic is the only membership authority. The former
	 * `memberistic_active_plan_id` user-meta fallback is gone: that meta is
	 * written on activation but never cleared on expiry or cancellation, so it
	 * kept lapsed members inside members-only surfaces. With Memberistic
	 * unavailable this fails closed for everyone but staff.
	 */
	private function current_user_is_member() {
		$user_id = get_current_user_id();
		$allowed = false;
		if ( $user_id ) {
			$allowed = function_exists( 'memberistic_user_has_active_membership' )
				? (bool) memberistic_user_has_active_membership( $user_id )
				: current_user_can( 'manage_g2ab_bookings' );
		}
		return (bool) apply_filters( 'g2ab_user_is_member', $allowed, $user_id, (object) array( 'members_only' => 1 ), '' );
	}

	private function get_public_lane_booking_type() {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}g2ab_booking_types WHERE slug = %s AND is_active = 1 AND members_only = 0 LIMIT 1",
			'lane-booking'
		) );
	}

	/**
	 * Per-instance inline JS. Selects its root by id so page-builders and
	 * caching plugins can't break the binding by inserting nodes between
	 * the wrapper and the script.
	 *
	 * @param string $instance_id Widget root element id.
	 * @param array  $view        Display state: member_included(bool),
	 *                            plan_name(string), pricing(array from
	 *                            display_pricing_for_booking_type()),
	 *                            custom_submit_label(string, '' = payment-aware).
	 */
	private function render_inline_bootstrap( $instance_id, $view = array() ) {
		$pricing = isset( $view['pricing'] ) && is_array( $view['pricing'] ) ? $view['pricing'] : array();
		$config  = array(
			'rest_url'    => esc_url_raw( rest_url( G2AB_REST_NAMESPACE . '/' ) ),
			'ajax_url'    => esc_url_raw( admin_url( 'admin-ajax.php' ) ),
			'nonce'       => wp_create_nonce( 'wp_rest' ),
			'instance_id' => $instance_id,
			'currency_prefix'     => $this->currency_prefix(),
			'member_included'     => ! empty( $view['member_included'] ),
			'plan_name'           => (string) ( $view['plan_name'] ?? '' ),
			'custom_submit_label' => (string) ( $view['custom_submit_label'] ?? '' ),
			'pricing'     => array(
				'unit_subtotal' => (float) ( $pricing['subtotal'] ?? 0 ),
				'unit_discount' => (float) ( $pricing['discount_amount'] ?? 0 ),
				'unit_total'    => (float) ( $pricing['total'] ?? 0 ),
			),
			'i18n'        => array(
				'loading'  => __( 'Loading available times…', 'g2a-booking' ),
				'no_slots' => __( 'No times available on this date.', 'g2a-booking' ),
				'closed'   => __( 'Closed on this date.', 'g2a-booking' ),
				'submitting' => __( 'Reserving…', 'g2a-booking' ),
				'failed'   => __( 'Could not complete booking. Please try again.', 'g2a-booking' ),
				'pick_first' => __( 'Please choose a date and time first.', 'g2a-booking' ),
				'confirm_reservation' => __( 'Confirm reservation', 'g2a-booking' ),
				/* translators: %s formatted amount */
				'pay_securely'        => __( 'Pay %s securely', 'g2a-booking' ),
				'invalid_email'       => __( 'Please enter a valid email address.', 'g2a-booking' ),
				'required_fields'     => __( 'Please fill in the highlighted required fields.', 'g2a-booking' ),
				'checkout_hold'       => __( 'Checkout hold — payment required. Your lane is held for a short time while you complete secure checkout.', 'g2a-booking' ),
				'redirecting'         => __( 'Redirecting to secure checkout…', 'g2a-booking' ),
				'confirmed_title'     => __( 'Booking confirmed', 'g2a-booking' ),
				'hold_note'           => __( 'Your reservation is not confirmed until payment is completed.', 'g2a-booking' ),
				'months'   => array(
					__( 'January', 'g2a-booking' ), __( 'February', 'g2a-booking' ), __( 'March', 'g2a-booking' ), __( 'April', 'g2a-booking' ),
					__( 'May', 'g2a-booking' ), __( 'June', 'g2a-booking' ), __( 'July', 'g2a-booking' ), __( 'August', 'g2a-booking' ),
					__( 'September', 'g2a-booking' ), __( 'October', 'g2a-booking' ), __( 'November', 'g2a-booking' ), __( 'December', 'g2a-booking' ),
				),
			),
		);
		?>
		<script>
		// ── Global safety net (runs once per page) ─────────────────────────
		// Catches submit on any .g2ab-form even if the per-instance bootstrap
		// below never runs (page-builder removes the script, JS minifier
		// breaks the IIFE, etc). Without this, the form would submit as
		// GET and dump all fields into the URL.
		if (!window.__g2abFormGuard) {
			window.__g2abFormGuard = true;
			document.addEventListener('submit', function(e){
				var form = e.target;
				if (form && form.nodeType === 1 && (form.classList.contains('g2ab-form') || form.getAttribute('data-g2ab-form') === '1')) {
					// preventDefault stops the native GET submit. Do NOT stopPropagation
					// here — that would also keep the per-instance AJAX submit handler
					// (bound on the same form) from ever receiving the event.
					e.preventDefault();
				}
			}, true);
		}

		(function(config){
			var root = config.instance_id ? document.getElementById(config.instance_id) : null;
			if (!root || !root.classList || !root.classList.contains('g2ab-booking') || root.dataset.g2abBooted) return;
			root.dataset.g2abBooted = '1';

			var $ = function(sel, ctx){ return (ctx || root).querySelector(sel); };
			var $$ = function(sel, ctx){ return Array.prototype.slice.call((ctx || root).querySelectorAll(sel)); };
			// Public GET endpoints must NOT carry a nonce: booking pages are
			// served to logged-out visitors from a full-page/edge cache, so the
			// nonce baked into the HTML goes stale — and core rejects a
			// present-but-invalid X-WP-Nonce with a 403 before the route's
			// permission_callback even runs, blanking availability for guests.
			function headers(hasBody){ var h = {}; if (hasBody !== false) { h['Content-Type'] = 'application/json'; if (config.nonce) h['X-WP-Nonce'] = config.nonce; } return h; }
			function pad(n){ return n < 10 ? '0'+n : ''+n; }
			function ymd(d){ return d.getFullYear() + '-' + pad(d.getMonth()+1) + '-' + pad(d.getDate()); }
			// Site-currency formatter (prefix localised from PHP — no hardcoded '$').
			function money(n){ return (config.currency_prefix || '$') + (Math.round(Number(n) * 100) / 100).toFixed(2); }
			// Remember uuid → confirm_token before redirecting to the gateway so a
			// ?g2ab_cancel return (which carries no token) can still offer
			// "Try payment again" via resume-payment.
			function storePayCtx(uuid, token){
				if (!uuid || !token) return;
				try {
					var raw = window.sessionStorage.getItem('g2abPayCtx');
					var map = raw ? JSON.parse(raw) : {};
					map[uuid] = { t: token, ts: Date.now() };
					window.sessionStorage.setItem('g2abPayCtx', JSON.stringify(map));
				} catch (e) { /* storage unavailable — resume just won't be offered */ }
			}

			// ── state ───────────────────────────────────────────────
			var singleId = root.querySelector('[data-single-resource-id]');
			var singleName = root.querySelector('[data-single-resource-name]');
			var firstChip = root.querySelector('.g2ab-chip.is-selected');
			var state = {
				resourceId: singleId ? parseInt(singleId.value, 10) : (firstChip ? parseInt(firstChip.dataset.resourceId, 10) : 0),
				resourceName: singleName ? singleName.value : (firstChip ? firstChip.dataset.resourceName : ''),
				date: '',
				slot: null,
				viewYear: 0,
				viewMonth: 0
			};

			// ── stage navigation ────────────────────────────────────
			function showStage(name){
				$$('.g2ab-stage__panel').forEach(function(p){
					var active = p.dataset.stage === name;
					p.classList.toggle('is-active', active);
				});
			}

			// ── done-stage recap + confetti ─────────────────────────
			// Recap is built entirely from what the visitor already picked
			// (state.resourceName / state.slot / party size) — the server
			// doesn't need to echo it back.
			function fillDoneRecap(partySize){
				var recap = $('[data-done-recap]');
				if (!recap) return;
				var resourceEl = $('[data-done-recap-resource]');
				var whenEl = $('[data-done-recap-when]');
				var partyRow = $('[data-done-recap-party-row]');
				var partyEl = $('[data-done-recap-party]');
				if (resourceEl) resourceEl.textContent = state.resourceName || '';
				if (whenEl && state.slot) {
					var human = state.slot.start;
					try {
						var dt = new Date(state.slot.start.replace(' ', 'T'));
						human = dt.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' }) + ' · ' + state.slot.label;
					} catch (e) { /* keep raw start_at */ }
					whenEl.textContent = human;
				}
				var party = parseInt(partySize, 10);
				if (partyRow && partyEl && party > 0) {
					partyEl.textContent = String(party);
					partyRow.hidden = false;
				} else if (partyRow) {
					partyRow.hidden = true;
				}
				recap.hidden = false;
			}

			// Purely decorative — never blocks or delays the confirmation
			// itself, and is a no-op for prefers-reduced-motion (the CSS
			// hides the container; this skips spawning pieces entirely so
			// there's no work to do either).
			function burstConfetti(container){
				if (!container) return;
				if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
				var colors = ['var(--g2ab-primary)', 'var(--g2ab-accent)', '#FFFFFF'];
				var pieceCount = 28;
				for (var i = 0; i < pieceCount; i++) {
					var piece = document.createElement('span');
					piece.className = 'g2ab-done__confetti-piece';
					piece.style.left = (Math.random() * 100) + '%';
					piece.style.background = colors[i % colors.length];
					piece.style.animationDuration = (900 + Math.random() * 700) + 'ms';
					piece.style.animationDelay = (Math.random() * 250) + 'ms';
					piece.style.transform = 'rotate(' + Math.floor(Math.random() * 360) + 'deg)';
					container.appendChild(piece);
				}
				window.setTimeout(function(){ container.innerHTML = ''; }, 2200);
			}

			// ── calendar render ─────────────────────────────────────
			function renderCalendar(){
				var grid = $('[data-cal-grid]');
				var titleEl = $('[data-cal-title]');
				if (!grid || !titleEl) return;
				var months = config.i18n.months;
				var year = state.viewYear, month = state.viewMonth;
				titleEl.textContent = months[month] + ' ' + year;

				// Build day list. Week starts Monday (locale-friendly default for ranges).
				var first = new Date(year, month, 1);
				var startDay = (first.getDay() + 6) % 7; // 0 = Mon
				var daysInMonth = new Date(year, month + 1, 0).getDate();
				var today = root.dataset.today;
				var maxDays = parseInt(root.dataset.maxDays || '90', 10);
				var maxDate = new Date();
				maxDate.setDate(maxDate.getDate() + maxDays);

				var html = '';
				for (var i = 0; i < startDay; i++) {
					html += '<button class="g2ab-cal__cell is-empty" type="button" disabled></button>';
				}
				for (var d = 1; d <= daysInMonth; d++) {
					var cellDate = new Date(year, month, d);
					var iso = ymd(cellDate);
					var isPast = iso < today;
					var isTooFar = cellDate > maxDate;
					var disabled = isPast || isTooFar;
					var selected = iso === state.date;
					var cls = 'g2ab-cal__cell' + (disabled ? ' is-disabled' : ' is-clickable') + (selected ? ' is-selected' : '');
					html += '<button class="' + cls + '" type="button" data-date="' + iso + '"' + (disabled ? ' disabled' : '') + '>' + d + '</button>';
				}
				grid.innerHTML = html;
			}

			function shiftMonth(delta){
				var d = new Date(state.viewYear, state.viewMonth + delta, 1);
				state.viewYear = d.getFullYear();
				state.viewMonth = d.getMonth();
				renderCalendar();
			}

			// ── slot loading ────────────────────────────────────────
			// Monotonic request counter: a slow availability response for an
			// OLD resource/date selection must never overwrite the newer one.
			var slotsReq = 0;
			function loadSlots(){
				var box = $('[data-slots]');
				var hint = $('[data-slots-hint]');
				if (!box) return;
				var seq = ++slotsReq;
				if (!state.resourceId || !state.date) {
					box.innerHTML = '';
					if (hint) { hint.style.display = ''; hint.textContent = config.i18n.pick_first || 'Pick a date'; }
					return;
				}
				if (hint) { hint.style.display = ''; hint.textContent = config.i18n.loading; }
				box.innerHTML = '';
				fetch(config.rest_url + 'availability?resource_id=' + encodeURIComponent(state.resourceId) + '&date=' + encodeURIComponent(state.date) + '&duration=' + encodeURIComponent(root.dataset.duration || 60), { headers: headers(false) })
					.then(function(r){ return r.json(); })
					.then(function(json){
						if (seq !== slotsReq) return; // stale response — a newer selection is in flight/rendered.
						var data = json && json.success ? json.data : null;
						if (hint) hint.style.display = 'none';
						if (!data) { box.innerHTML = '<p class="g2ab-muted">' + config.i18n.no_slots + '</p>'; return; }
						if (data.closed) { box.innerHTML = '<p class="g2ab-muted">' + config.i18n.closed + '</p>'; return; }
						if (!data.slots || !data.slots.length) { box.innerHTML = '<p class="g2ab-muted">' + config.i18n.no_slots + '</p>'; return; }
						data.slots.forEach(function(slot){
							var btn = document.createElement('button');
							btn.type = 'button';
							btn.className = 'g2ab-slot';
							btn.textContent = slot.label;
							btn.disabled = !slot.available;
							btn.dataset.start = slot.start;
							btn.dataset.end = slot.end;
							if (slot.available) {
								btn.addEventListener('click', function(){
									$$('.g2ab-slot', box).forEach(function(s){ s.classList.remove('is-selected'); });
									btn.classList.add('is-selected');
									state.slot = { start: slot.start, end: slot.end, label: slot.label };
									updateSummary();
									var go = $('[data-go-form]');
									if (go) go.disabled = false;
								});
							}
							box.appendChild(btn);
						});
					})
					.catch(function(){
						if (seq !== slotsReq) return;
						if (hint) hint.style.display = 'none';
						box.innerHTML = '<p class="g2ab-muted">' + config.i18n.no_slots + '</p>';
					});
			}

			// ── order summary + payment-aware CTA ───────────────────
			function partySize(){
				var input = form ? form.querySelector('[name="fields[party_size]"]') : null;
				var p = input ? parseInt(input.value, 10) : 1;
				return p > 0 ? p : 1;
			}
			function updateCta(total){
				if (config.custom_submit_label) return; // admin label always wins.
				var cta = $('[data-submit-cta]');
				if (!cta) return;
				if (config.member_included || total <= 0) {
					cta.textContent = config.i18n.confirm_reservation;
				} else {
					cta.textContent = config.i18n.pay_securely.replace('%s', money(total));
				}
			}
			// Re-render the order summary from the server-calculated per-unit
			// pricing whenever the party size changes (dynamic price updates).
			function renderOrder(){
				if (config.member_included) { updateCta(0); return; }
				var qty = partySize();
				var sub = config.pricing.unit_subtotal * qty;
				var disc = config.pricing.unit_discount * qty;
				var total = config.pricing.unit_total * qty;
				var qtyEl = $('[data-order-qty]');
				if (qtyEl) qtyEl.textContent = String(qty);
				var subEl = $('[data-order-subtotal]');
				if (subEl) subEl.textContent = money(sub);
				var discRow = $('[data-order-discount-row]');
				if (discRow) {
					discRow.hidden = disc <= 0;
					var discEl = $('[data-order-discount]');
					if (discEl) discEl.textContent = '−' + money(disc);
				}
				$$('[data-order-total]').forEach(function(el){ el.textContent = money(total); });
				updateCta(total);
			}

			// ── client-side validation (server still validates) ─────
			function validateForm(showError){
				if (!form) return true;
				var els = $$('input, select, textarea', form);
				var checkedRadios = {};
				els.forEach(function(el){ if (el.type === 'radio' && el.checked) checkedRadios[el.name] = true; });
				var seenRadios = {};
				var firstBad = null;
				var badEmail = false;
				els.forEach(function(el){
					if (el.disabled || el.type === 'hidden' || el.type === 'submit' || el.type === 'button') return;
					var bad = false;
					if (el.required) {
						if (el.type === 'checkbox') {
							bad = !el.checked;
						} else if (el.type === 'radio') {
							if (seenRadios[el.name]) return;
							seenRadios[el.name] = true;
							bad = !checkedRadios[el.name];
						} else {
							bad = !String(el.value || '').trim();
						}
					}
					if (!bad && el.type === 'email' && String(el.value || '').trim()) {
						bad = !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(el.value).trim());
						if (bad) badEmail = true;
					}
					if (bad) {
						el.setAttribute('aria-invalid', 'true');
						if (!firstBad) firstBad = el;
					} else {
						el.removeAttribute('aria-invalid');
					}
				});
				if (firstBad) {
					if (showError) showError(badEmail && firstBad.type === 'email' ? config.i18n.invalid_email : config.i18n.required_fields);
					try { firstBad.focus(); } catch (e) { /* noop */ }
					return false;
				}
				return true;
			}

			function updateSummary(){
				var pill = $('[data-summary-pill]');
				var line = $('[data-summary-line]');
				if (!state.slot) {
					if (pill) { pill.hidden = true; pill.textContent = ''; }
					if (line) line.textContent = '';
					return;
				}
				var human = '';
				try {
					var dt = new Date(state.slot.start.replace(' ', 'T'));
					human = dt.toLocaleDateString(undefined, { weekday:'long', month:'short', day:'numeric' }) + ' · ' + state.slot.label;
				} catch (e) { human = state.slot.start; }
				if (pill) { pill.hidden = false; pill.textContent = (state.resourceName ? state.resourceName + ' · ' : '') + human; }
				if (line) line.textContent = (state.resourceName ? state.resourceName + ' · ' : '') + human;
			}

			// ── event bindings ──────────────────────────────────────
			// Lane / resource chip selector
			$$('.g2ab-chip').forEach(function(chip){
				chip.addEventListener('click', function(){
					$$('.g2ab-chip').forEach(function(c){ c.classList.remove('is-selected'); });
					chip.classList.add('is-selected');
					state.resourceId = parseInt(chip.dataset.resourceId, 10);
					state.resourceName = chip.dataset.resourceName || '';
					state.slot = null;
					var go = $('[data-go-form]'); if (go) go.disabled = true;
					loadSlots();
					updateSummary();
				});
			});

			// Calendar nav
			var prev = $('[data-cal-prev]'); if (prev) prev.addEventListener('click', function(){ shiftMonth(-1); });
			var next = $('[data-cal-next]'); if (next) next.addEventListener('click', function(){ shiftMonth(1); });

			// Calendar day click
			var grid = $('[data-cal-grid]');
			if (grid) {
				grid.addEventListener('click', function(e){
					var cell = e.target.closest('.g2ab-cal__cell.is-clickable');
					if (!cell || !grid.contains(cell)) return;
					state.date = cell.dataset.date;
					state.slot = null;
					var go = $('[data-go-form]'); if (go) go.disabled = true;
					$$('.g2ab-cal__cell', grid).forEach(function(c){ c.classList.remove('is-selected'); });
					cell.classList.add('is-selected');
					loadSlots();
				});
			}

			// Continue → form
			var goBtn = $('[data-go-form]');
			if (goBtn) goBtn.addEventListener('click', function(){
				if (!state.slot) return;
				showStage('form');
			});

			// Back from form → time
			$$('[data-back-time]').forEach(function(b){
				b.addEventListener('click', function(){ showStage('time'); });
			});

			// "Book Another Lane" from the done stage → reset the slot/date
			// (keep the chosen resource) and re-render a fresh calendar.
			var againBtn = $('[data-book-another]');
			if (againBtn) againBtn.addEventListener('click', function(){
				state.date = '';
				state.slot = null;
				var recap = $('[data-done-recap]');
				if (recap) recap.hidden = true;
				var go = $('[data-go-form]');
				if (go) go.disabled = true;
				var form = $('.g2ab-form');
				if (form) form.reset();
				renderCalendar();
				showStage('time');
			});

			// Submit form
			var form = $('.g2ab-form');
			if (form) {
				form.addEventListener('submit', function(event){
					event.preventDefault();
					var errEl = $('[data-form-error]', form);
					var statusEl = $('[data-form-status]', form);
					var submit = form.querySelector('button[type="submit"]');
					var originalLabel = submit ? submit.textContent : '';
					function showErr(msg){
						if (errEl) { errEl.textContent = msg; errEl.hidden = false; }
					}
					function showStatus(msg){
						if (statusEl) { statusEl.textContent = msg; statusEl.hidden = false; }
					}
					try {
					if (statusEl) { statusEl.hidden = true; statusEl.textContent = ''; }
					if (!state.resourceId || !state.slot) {
						showErr(config.i18n.pick_first);
						return;
					}
					// Client-side validation (required fields, email format) with
					// focus moved to the first invalid control. The server still
					// re-validates everything.
					if (!validateForm(showErr)) {
						return;
					}
					var fields = {};
					new FormData(form).forEach(function(value, key){
						var m = key.match(/^fields\[(.+)\]$/);
						if (m) fields[m[1]] = value;
					});
					if (errEl) { errEl.hidden = true; errEl.textContent = ''; }
					if (submit) { submit.disabled = true; submit.textContent = config.i18n.submitting; }
					var payload = JSON.stringify({
						booking_type_id: parseInt(root.dataset.bookingTypeId, 10) || 0,
						resource_id: state.resourceId,
						form_id: parseInt(root.dataset.formId, 10) || 0,
						start_at: state.slot.start,
						party_size: parseInt(fields.party_size || 1, 10),
						fields: fields
					});
					function postBooking(nonce){
						var h = { 'Content-Type': 'application/json' };
						if (nonce) h['X-WP-Nonce'] = nonce;
						return fetch(config.rest_url + 'bookings', { method: 'POST', headers: h, credentials: 'same-origin', body: payload })
							.then(function(r){ return r.json().then(function(j){ return {ok:r.ok, status:r.status, body:j}; }, function(){ return {ok:r.ok, status:r.status, body:null}; }); });
					}
					function isStaleNonce(res){
						return res && res.status === 403 && res.body && (res.body.code === 'g2ab_invalid_nonce' || res.body.code === 'rest_cookie_invalid_nonce');
					}
					postBooking(config.nonce)
					.then(function(res){
						// If the page's nonce was stale (e.g. served from a full-page
						// cache), grab a fresh one from the uncached endpoint and retry
						// the booking POST once before giving up.
						if (!isStaleNonce(res)) return res;
						// Refresh via admin-ajax (NOT the REST /nonce route): a logged-in
						// member's nonceless REST call hits the same cookie-nonce gate and
						// also returns "Cookie check failed". admin-ajax runs in their
						// authenticated context and mints a nonce valid for them.
						var ajaxBase = config.ajax_url || (window.location.origin + '/wp-admin/admin-ajax.php');
						var refreshUrl = ajaxBase + (ajaxBase.indexOf('?') === -1 ? '?' : '&') + 'action=g2ab_refresh_nonce';
						return fetch(refreshUrl, { headers: { 'Accept': 'application/json' }, credentials: 'same-origin' })
							.then(function(r){ return r.json(); })
							.then(function(j){
								var fresh = j && j.data && j.data.nonce ? j.data.nonce : '';
								if (fresh) config.nonce = fresh;
								return postBooking(fresh || config.nonce);
							})
							.catch(function(){ return res; });
					})
					.then(function(res){
						if (!res.ok || !res.body || !res.body.success) {
							var msg = (res.body && res.body.message) || config.i18n.failed;
							throw new Error(msg);
						}
						var data = res.body.data || {};
						var isHold = !!data.payment_required || data.state === 'checkout_hold';
						var isConfirmed = data.state === 'confirmed' || data.status === 'confirmed' || data.status === 'paid';

						if (isHold) {
							// Checkout hold — NOT a confirmed booking. Announce the
							// hold, keep the confirm_token for a possible cancel
							// return, and hand off to the gateway.
							storePayCtx(data.uuid, data.confirm_token);
							showStatus((data.message || config.i18n.checkout_hold) + (data.redirect_url ? ' ' + config.i18n.redirecting : ' ' + config.i18n.hold_note));
							if (data.redirect_url) {
								window.setTimeout(function(){ window.location.href = data.redirect_url; }, 150);
								return;
							}
							// No checkout URL (e.g. idempotent replay of a pending
							// attempt): never show a confirmation — surface the hold
							// copy and let the visitor retry.
							if (submit) { submit.disabled = false; submit.textContent = originalLabel; }
							return;
						}

						if (!isConfirmed) {
							// Unknown/unpaid state — never render the confirmed panel.
							showStatus(data.message || config.i18n.hold_note);
							if (submit) { submit.disabled = false; submit.textContent = originalLabel; }
							return;
						}

						// Confirmed by the server (free booking or member-included $0).
						var titleEl = $('[data-done-title]');
						if (titleEl) titleEl.textContent = config.i18n.confirmed_title;
						var msgEl = $('[data-done-msg]'); var uuidEl = $('[data-done-uuid]');
						if (msgEl) msgEl.textContent = data.message || '';
						if (uuidEl) uuidEl.textContent = data.uuid || '';
						fillDoneRecap(fields.party_size);
						showStage('done');
						burstConfetti($('[data-done-confetti]'));
					})
					.catch(function(err){
						if (errEl) { errEl.textContent = err.message || config.i18n.failed; errEl.hidden = false; }
						if (submit) { submit.disabled = false; submit.textContent = originalLabel; }
					});
					} catch (e) {
						// Surface any synchronous error on-screen instead of leaving the
						// button silently stuck — turns a "dead button" into a readable
						// message and re-enables the button so it can be retried.
						if (errEl) { errEl.textContent = (e && e.message) ? ('Booking error: ' + e.message) : config.i18n.failed; errEl.hidden = false; }
						if (submit) { submit.disabled = false; submit.textContent = originalLabel; }
					}
				});
			}

			// Party-size changes re-price the order summary + CTA live.
			if (form) {
				var partyInput = form.querySelector('[name="fields[party_size]"]');
				if (partyInput) {
					['change', 'input'].forEach(function(ev){
						partyInput.addEventListener(ev, renderOrder);
					});
				}
			}

			// ── boot ────────────────────────────────────────────────
			var now = new Date();
			state.viewYear = now.getFullYear();
			state.viewMonth = now.getMonth();
			renderCalendar();
			renderOrder();
			showStage('time');
		})(<?php echo wp_json_encode( $config ); ?>);
		</script>
		<?php
	}
}
