<?php
/**
 * Auto-Responder — emails a confirmation to the submitter after a successful
 * capture. Listens for the `WPISTIC_CF_submission_captured` action emitted by
 * WPISTIC_CF_Capture::store().
 *
 * @package WPISTIC_CF
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sends auto-responder emails.
 */
class WPISTIC_CF_Autoresponder {

	/**
	 * Register hooks.
	 */
	public function register() {
		add_action( 'WPISTIC_CF_submission_captured', [ $this, 'maybe_send' ], 20, 3 );
	}

	/**
	 * Send the auto-responder email if enabled and the submitter has a valid
	 * email address.
	 *
	 * @param int    $submission_id Submission ID.
	 * @param string $form_name     Form name.
	 * @param array  $fields        Captured fields (label => value).
	 */
	public function maybe_send( $submission_id, $form_name, $fields ) {
		// Global kill-switch. Set WPCF_EMAIL_DISABLED in wp-config.php on
		// staging/dev to suppress all outbound auto-responders without
		// touching the per-form admin toggle.
		if ( ( defined( 'WPCF_EMAIL_DISABLED' ) && WPCF_EMAIL_DISABLED )
			|| (bool) get_option( 'WPISTIC_CF_emails_disabled', false ) ) {
			return;
		}

		if ( '1' !== get_option( 'WPISTIC_CF_ar_enabled', '0' ) ) {
			return;
		}

		$submission = WPISTIC_CF_Database::get_submission( (int) $submission_id );
		if ( ! $submission || ! is_email( $submission->sender_email ) ) {
			return;
		}

		// Per-target throttle: do not re-send to the same email more than
		// once per hour, even if a script floods the capture endpoint.
		$throttle_key = 'wpcf_ar_' . md5( strtolower( trim( $submission->sender_email ) ) );
		if ( false !== get_transient( $throttle_key ) ) {
			return;
		}
		set_transient( $throttle_key, 1, HOUR_IN_SECONDS );

		$placeholders = [
			'{name}'      => $submission->sender_name !== '' ? $submission->sender_name : __( 'there', 'wpistic-contact-form' ),
			'{form}'      => $form_name,
			'{message}'   => $submission->message,
			'{site_name}' => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'{site_url}'  => home_url( '/' ),
			'{date}'      => date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ),
		];

		$subject = strtr( (string) get_option( 'WPISTIC_CF_ar_subject', '' ), $placeholders );
		$body    = strtr( (string) get_option( 'WPISTIC_CF_ar_body', '' ), $placeholders );
		if ( '' === trim( $subject ) || '' === trim( $body ) ) {
			return;
		}

		$from_name  = get_option( 'WPISTIC_CF_reply_from_name', get_bloginfo( 'name' ) );
		$from_email = get_option( 'WPISTIC_CF_reply_from_email', get_option( 'admin_email' ) );
		$headers    = [];
		if ( is_email( $from_email ) ) {
			$headers[] = sprintf( 'From: %s <%s>', $from_name, $from_email );
			$headers[] = 'Reply-To: ' . $from_email;
		}

		// Branded HTML mode (default on): the plain-text body the admin
		// wrote — placeholders already substituted above — is escaped,
		// linkified and wrapped in the shared 600px shell. Disable via the
		// Auto-Responder settings tab to fall back to plain text.
		if ( '1' === get_option( 'WPISTIC_CF_ar_html', '1' ) && class_exists( 'WPISTIC_CF_Email_Template' ) ) {
			$inner = wpautop( make_clickable( esc_html( $body ) ) );
			$body  = WPISTIC_CF_Email_Template::wrap( $inner, [ 'title' => $subject ] );
			$headers[] = 'Content-Type: text/html; charset=UTF-8';
		}

		$sent = WPISTIC_CF_Capture::send_internal( $submission->sender_email, $subject, $body, $headers );
		if ( ! $sent && defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( sprintf( '[WPISTIC_CF] Auto-responder email failed for submission #%d.', (int) $submission_id ) );
		}
	}

	/**
	 * Replay the auto-responder for one existing submission.
	 *
	 * @param int $submission_id Submission ID.
	 */
	public static function replay_for_submission( $submission_id ) {
		$row = WPISTIC_CF_Database::get_submission( (int) $submission_id );
		if ( ! $row ) {
			return;
		}
		$fields = json_decode( (string) $row->fields, true );
		$fields = is_array( $fields ) ? $fields : [];
		( new self() )->maybe_send( (int) $row->id, (string) $row->form_name, $fields );
	}
}
