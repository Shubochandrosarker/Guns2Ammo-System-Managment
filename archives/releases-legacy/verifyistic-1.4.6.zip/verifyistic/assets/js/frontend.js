/**
 * Verifyistic Frontend JS
 * WordPressistic
 */
(function ($) {
    'use strict';

    var VFY = {

        data: window.verifyisticData || {},
        cookieName: 'verifyistic_verified',

        init: function () {
            // Check if already verified via cookie
            if (this.getCookie(this.cookieName)) {
                return; // Already verified
            }

            this.bindEvents();
            this.showOverlay();
            // Replace the inline token AND nonce (which may have come from a
            // cached HTML response) with freshly-minted ones. Cached pages
            // share a single token across all visitors and freeze the nonce
            // until it expires — a stale nonce made every submit 403 into
            // "Network error" with no way in. Fetching per-visitor from the
            // uncached admin-ajax endpoint sidesteps the cache.
            this.refreshToken();
        },

        // ── Fetch a fresh signed form token + nonce ──────────────
        // Deliberately sends no nonce: this endpoint is the recovery
        // path for a stale nonce, so it must not depend on one.
        refreshToken: function (done, force) {
            var self = this;
            var cacheKey = 'verifyistic_token_cache';
            if (!force && window.sessionStorage) {
                try {
                    var cached = JSON.parse(sessionStorage.getItem(cacheKey) || 'null');
                    if (cached && cached.token && cached.nonce && cached.expiresAt && cached.expiresAt > Date.now()) {
                        $('#vfy-form-token').val(cached.token);
                        self.data.nonce = cached.nonce;
                        if (typeof done === 'function') { done(); }
                        return;
                    }
                } catch (e) {}
            }
            $.post(this.data.ajaxUrl, {
                action: 'verifyistic_token'
            }, function (res) {
                if (res && res.success && res.data) {
                    if (res.data.token) { $('#vfy-form-token').val(res.data.token); }
                    if (res.data.nonce) { self.data.nonce = res.data.nonce; }
                    if (window.sessionStorage && res.data.token && res.data.nonce) {
                        try {
                            sessionStorage.setItem(cacheKey, JSON.stringify({
                                token: res.data.token,
                                nonce: res.data.nonce,
                                expiresAt: Date.now() + (10 * 60 * 1000)
                            }));
                        } catch (e) {}
                    }
                }
            }).always(function () {
                if (typeof done === 'function') { done(); }
            });
        },

        // ── Show Overlay ─────────────────────────────────────────
        showOverlay: function () {
            $('#verifyistic-overlay').fadeIn(200);
            $('body').addClass('verifyistic-locked');
        },

        // ── Hide Overlay ─────────────────────────────────────────
        hideOverlay: function (delay) {
            delay = delay || 0;
            setTimeout(function () {
                $('#verifyistic-overlay').fadeOut(300, function () {
                    $(this).remove();
                    $('body').removeClass('verifyistic-locked');
                });
            }, delay);
        },

        // ── Bind Events ──────────────────────────────────────────
        bindEvents: function () {
            var self = this;

            // DOB / ID form submit
            $(document).on('submit', '#vfy-verify-form', function (e) {
                e.preventDefault();
                self.handleFormSubmit($(this));
            });

            // Yes button
            $(document).on('click', '#vfy-btn-yes', function (e) {
                e.preventDefault();
                self.handleYesNo('yes');
            });

            // No button
            $(document).on('click', '#vfy-btn-no', function (e) {
                e.preventDefault();
                self.handleYesNo('no');
            });

            // File upload preview
            $(document).on('change', '.vfy-file-input', function () {
                var file   = this.files[0];
                var $wrap  = $(this).closest('.vfy-upload-area');
                var $prev  = $wrap.find('.vfy-upload-preview');
                if (file) {
                    $prev.text(file.name);
                }
            });

            // Prevent click-through on popup card
            $(document).on('click', '#verifyistic-popup', function (e) {
                e.stopPropagation();
            });

            // Prevent right-click on overlay
            $(document).on('contextmenu', '#verifyistic-overlay', function (e) {
                e.preventDefault();
            });

            // Disable keyboard escape
            $(document).on('keydown', function (e) {
                if (e.key === 'Escape' && $('#verifyistic-overlay').length) {
                    e.preventDefault();
                    e.stopPropagation();
                    return false;
                }
            });
        },

        // ── Handle DOB / ID Form Submit ──────────────────────────
        handleFormSubmit: function ($form) {
            var self  = this;
            var $btn  = $form.find('.vfy-btn-submit');
            var $err  = $form.find('.vfy-error');
            var mode  = this.data.mode || 'dob';

            // Client-side validation
            if (!this.validateForm($form, mode)) return;

            // Loading state
            this.setButtonLoading($btn, true);
            $err.removeClass('show');

            var retriedAuth = false;
            function send() {
                var formData = new FormData( $form[0] );
                formData.append('action',   'verifyistic_verify');
                formData.append('nonce',    self.data.nonce);
                formData.append('mode',     mode);
                formData.append('page_url', window.location.href);
                // Anti-bot guard fields (shared, live outside the <form>).
                formData.append('vfy_hp',    $('#vfy-hp').val() || '');
                formData.append('vfy_token', $('#vfy-form-token').val() || '');

                $.ajax({
                    url:         self.data.ajaxUrl,
                    type:        'POST',
                    data:        formData,
                    processData: false,
                    contentType: false,
                    success: function (res) {
                        self.setButtonLoading($btn, false);
                        if (res.success) {
                            self.onVerified(res.data, $form);
                        } else {
                            self.showError($err, res.data.message || self.data.strings.ageError);
                            // Mint a fresh token so the user's next attempt
                            // isn't blocked by an expired or stale-cache token.
                            self.refreshToken(null, true);
                        }
                    },
                    error: function (xhr) {
                        // A 403 here is a stale nonce served from a cached
                        // page, not a network problem: mint a fresh nonce +
                        // token from the uncached endpoint and retry once,
                        // instead of walling the visitor off with an error.
                        if (!retriedAuth && xhr && xhr.status === 403) {
                            retriedAuth = true;
                            self.refreshToken(send, true);
                            return;
                        }
                        self.setButtonLoading($btn, false);
                        self.showError($err, 'Network error. Please try again.');
                        self.refreshToken(null, true);
                    }
                });
            }
            send();
        },

        // ── Handle Yes/No Buttons ────────────────────────────────
        handleYesNo: function (choice) {
            var self = this;
            var $btn = choice === 'yes' ? $('#vfy-btn-yes') : $('#vfy-btn-no');

            this.setButtonLoading($btn, true);

            if (choice === 'no') {
                // Fire decline AJAX
                $.post(this.data.ajaxUrl, {
                    action:   'verifyistic_decline',
                    nonce:    this.data.nonce,
                    page_url: window.location.href
                }, function (res) {
                    self.setButtonLoading($btn, false);
                    if (res.success && res.data.redirect) {
                        window.location.href = res.data.redirect;
                    } else {
                        // No redirect — go back
                        window.history.back();
                    }
                }).fail(function () {
                    window.history.back();
                });
                return;
            }

            // YES: verify
            var retriedAuth = false;
            function sendYes() {
                $.post(self.data.ajaxUrl, {
                    action:    'verifyistic_verify',
                    nonce:     self.data.nonce,
                    mode:      'yes_no',
                    page_url:  window.location.href,
                    vfy_hp:    $('#vfy-hp').val() || '',
                    vfy_token: $('#vfy-form-token').val() || ''
                }, function (res) {
                    self.setButtonLoading($btn, false);
                    if (res.success && res.data && res.data.token) {
                        self.onVerified(res.data, null);
                    } else {
                        self.showYesNoError((res && res.data && res.data.message) || 'Verification failed. Please try again.');
                        self.refreshToken(null, true);
                    }
                }).fail(function (xhr) {
                    // Stale cached nonce → 403: refresh + retry once before
                    // treating it as a real failure.
                    if (!retriedAuth && xhr && xhr.status === 403) {
                        retriedAuth = true;
                        self.refreshToken(sendYes, true);
                        return;
                    }
                    self.setButtonLoading($btn, false);
                    // SECURITY: do NOT let through on network failure. Fail closed.
                    self.showYesNoError('Network error. Please try again.');
                    self.refreshToken(null, true);
                });
            }
            sendYes();
        },

        // ── Yes/No error display (no DOB form available) ─────────
        showYesNoError: function (msg) {
            var $err = $('#vfy-yn-error');
            if (!$err.length) {
                $err = $('<div id="vfy-yn-error" class="vfy-error show" style="margin-top:12px;"><span class="vfy-error-text"></span></div>');
                $('#vfy-yn-content').append($err);
            }
            $err.find('.vfy-error-text').text(msg);
            $err.addClass('show');
        },

        // ── On Verified ──────────────────────────────────────────
        onVerified: function (data, $form) {
            // SECURITY: refuse to set cookie unless server returned a real token.
            // Previously fell back to the literal "1" which downstream consumers
            // (Memberistic, G2A Booking Engine) treated as a passed verification.
            if (!data || !data.token || String(data.token).length < 16) {
                this.showYesNoError('Verification could not be completed.');
                return;
            }
            // Set cookie
            var remember = $form
                ? $form.find('.vfy-remember-checkbox').is(':checked')
                : !!this.data.rememberMe;
            var days     = remember ? (parseInt(this.data.cookieDays) || 30) : 0;
            this.setCookie(this.cookieName, data.token, days);

            // Show success state
            if ($form) {
                $form.hide();
                $form.closest('.vfy-inner').find('.vfy-success-state').addClass('show');
            } else {
                // Yes/No — just show success briefly
                $('#vfy-yn-content').hide();
                $('#vfy-success-yn').addClass('show');
            }

            // Hide overlay after delay
            this.hideOverlay(1600);
        },

        // ── Validate Form ────────────────────────────────────────
        validateForm: function ($form, mode) {
            var $err = $form.find('.vfy-error');

            if (mode === 'dob') {
                // Assemble the Month / Day / Year dropdowns into a YYYY-MM-DD
                // value (mobile-friendly — no native date-spinner year scroll).
                var m = $form.find('#vfy-dob-month').val();
                var d = $form.find('#vfy-dob-day').val();
                var y = $form.find('#vfy-dob-year').val();
                if (!m || !d || !y) {
                    this.showError($err, this.data.strings.dobRequired);
                    return false;
                }
                m = parseInt(m, 10); d = parseInt(d, 10); y = parseInt(y, 10);
                var dt = new Date(y, m - 1, d);
                // Reject impossible dates (e.g. Feb 30) and future dates.
                if (dt.getFullYear() !== y || dt.getMonth() !== m - 1 || dt.getDate() !== d || dt > new Date()) {
                    this.showError($err, this.data.strings.dobInvalid);
                    return false;
                }
                var dob = y + '-' + (m < 10 ? '0' + m : m) + '-' + (d < 10 ? '0' + d : d);
                $form.find('#vfy-dob').val(dob);
                // Age check client-side
                var age = this.calculateAge(dob);
                if (age < parseInt(this.data.minAge)) {
                    this.showError($err, this.data.strings.ageError);
                    return false;
                }
            }

            if (mode === 'id_face') {
                var idFile     = $form.find('[name="id_file"]')[0];
                var selfieFile = $form.find('[name="selfie_file"]')[0];
                if (!idFile || !idFile.files.length) {
                    this.showError($err, this.data.strings.idRequired);
                    return false;
                }
                if (!selfieFile || !selfieFile.files.length) {
                    this.showError($err, this.data.strings.selfieReq);
                    return false;
                }
            }

            return true;
        },

        // ── Show Error ───────────────────────────────────────────
        showError: function ($el, msg) {
            $el.find('.vfy-error-text').text(msg);
            $el.addClass('show');
            $el[0].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        },

        // ── Button Loading State ─────────────────────────────────
        setButtonLoading: function ($btn, loading) {
            if (loading) {
                $btn.data('orig', $btn.html())
                    .prop('disabled', true)
                    .html('<span class="vfy-btn-spinner"></span> ' + (this.data.strings.verifying || 'Verifying…'));
            } else {
                $btn.prop('disabled', false).html($btn.data('orig') || $btn.html());
            }
        },

        // ── Calculate Age ────────────────────────────────────────
        calculateAge: function (dob) {
            var parts = dob.split('-');
            if (parts.length < 3) return -1;
            var birth = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
            if (isNaN(birth.getTime())) return -1;
            var today = new Date();
            var age   = today.getFullYear() - birth.getFullYear();
            var m     = today.getMonth() - birth.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) { age--; }
            return age;
        },

        // ── Cookie Helpers ───────────────────────────────────────
        setCookie: function (name, value, days) {
            var attrs = '';
            if (days) {
                var date = new Date();
                date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
                attrs += '; expires=' + date.toUTCString();
            }
            if (this.data && this.data.cookieDomain) {
                attrs += '; Domain=' + this.data.cookieDomain;
            }
            if (typeof window !== 'undefined' && window.location && window.location.protocol === 'https:') {
                attrs += '; Secure';
            }
            document.cookie = name + '=' + encodeURIComponent(value) + attrs + '; path=/; SameSite=Lax';
        },

        getCookie: function (name) {
            var nameEQ = name + '=';
            var ca     = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) === ' ') { c = c.substring(1, c.length); }
                if (c.indexOf(nameEQ) === 0) {
                    return decodeURIComponent(c.substring(nameEQ.length, c.length));
                }
            }
            return null;
        }
    };

    $(document).ready(function () {
        VFY.init();
    });

}(jQuery));
